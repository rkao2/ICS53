// helpers0.h
#include<stdio.h>
#include<stdlib.h>



int printArg(char*, int);

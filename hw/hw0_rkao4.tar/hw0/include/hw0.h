// Header file for hw0.c

#include<stdio.h>
#include<stdlib.h>

